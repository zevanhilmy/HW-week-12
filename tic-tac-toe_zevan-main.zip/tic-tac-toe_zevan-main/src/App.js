import React, { useState } from 'react';
import './output.css'

function Square({ val, onClick }) {
  return (
    <button
      className="square bg-transparent border-[2px] rounded-xl border-gray-300 w-[175px] h-[175px] flex justify-center items-center font-bold text-5xl"
      onClick={onClick}
    >
      {val}
    </button>
  );
}
function Board() {
  const [squares, setSquares] = useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);

  function selectSquare(i) {
    if (calcWinner(squares) || squares[i]) {
      return;
    }

    const newSquares = [...squares];
    newSquares[i] = xIsNext ? 'O' : 'X';
    setSquares(newSquares);
    setXIsNext(!xIsNext);
  }

  function renderSquare(i) {
    return <Square val={squares[i]} onClick={() => selectSquare(i)} />;
  }

  function calcWinner(squares) {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
  
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
  
    return null;
  }

  const winner = calcWinner(squares);
  let status;
  if (winner) {
    status = `The Winner is: ${winner}`;
  } else if (squares.every(Boolean)) {
    status = `Scratch: Cat's game`;
  } else {
    status = `Player Run: ${xIsNext ? 'O' : 'X'}`;
  }

  function restart() {
    setSquares(Array(9).fill(null));
    setXIsNext(true);
  }

  return (
    <div className="p-10">
      <div className="text-6xl font-bold mb-10 text-center">{status}</div>
      <div className="grid grid-cols-3 gap-3">
        {renderSquare(0)}
        {renderSquare(1)}
        {renderSquare(2)}
        {renderSquare(3)}
        {renderSquare(4)}
        {renderSquare(5)}
        {renderSquare(6)}
        {renderSquare(7)}
        {renderSquare(8)}
      </div>
      <div className='flex flex-row justify-center items-center '>
        <button
          className="w-2/3 mt-5 py-3 bg-green-500 text-white font-bold rounded hover:bg-green-700 text-2xl"
          onClick={restart}
        >
          Restart Game
        </button>
      </div>
    </div>
  );
}

function Game() {
  return (
    <div className="flex justify-center items-center h-screen bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500">
      <Board />
    </div>
  );
}

function App() {
  return <Game />;
}

export default App;